import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const assignmentStatusEnum = ["pending", "in_progress", "completed", "overdue"] as const;
export type AssignmentStatus = (typeof assignmentStatusEnum)[number];

export const assignments = pgTable("assignments", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: text("due_date"),
  status: text("status").$type<AssignmentStatus>().notNull().default("pending"),
});

export const insertAssignmentSchema = createInsertSchema(assignments).omit({
  id: true,
}).extend({
  title: z.string().min(1, "Title is required").max(200, "Title is too long"),
  description: z.string().max(1000, "Description is too long").optional(),
  dueDate: z.string().optional(),
  status: z.enum(assignmentStatusEnum).default("pending"),
});

export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
export type Assignment = typeof assignments.$inferSelect;

export const users = pgTable("users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
