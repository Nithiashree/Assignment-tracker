import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Plus, Calendar, FileText, CheckCircle2, Clock, AlertCircle, Loader2 } from "lucide-react";
import type { Assignment, InsertAssignment, AssignmentStatus } from "@shared/schema";
import { insertAssignmentSchema } from "@shared/schema";

function getStatusConfig(status: AssignmentStatus) {
  switch (status) {
    case "pending":
      return { label: "Pending", variant: "secondary" as const, icon: Clock };
    case "in_progress":
      return { label: "In Progress", variant: "default" as const, icon: Loader2 };
    case "completed":
      return { label: "Completed", variant: "outline" as const, icon: CheckCircle2 };
    case "overdue":
      return { label: "Overdue", variant: "destructive" as const, icon: AlertCircle };
    default:
      return { label: "Pending", variant: "secondary" as const, icon: Clock };
  }
}

function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { 
      month: "short", 
      day: "numeric", 
      year: "numeric" 
    });
  } catch {
    return dateString;
  }
}

function AssignmentCard({ assignment }: { assignment: Assignment }) {
  const statusConfig = getStatusConfig(assignment.status);
  const StatusIcon = statusConfig.icon;

  return (
    <Card className="p-6 hover-elevate transition-all" data-testid={`card-assignment-${assignment.id}`}>
      <div className="flex flex-col gap-3">
        <div className="flex items-start justify-between gap-4">
          <h3 className="text-base font-medium text-foreground" data-testid={`text-title-${assignment.id}`}>
            {assignment.title}
          </h3>
          <Badge variant={statusConfig.variant} className="shrink-0" data-testid={`badge-status-${assignment.id}`}>
            <StatusIcon className="w-3 h-3 mr-1" />
            {statusConfig.label}
          </Badge>
        </div>
        
        {assignment.description && (
          <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-description-${assignment.id}`}>
            {assignment.description}
          </p>
        )}
        
        {assignment.dueDate && (
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <Calendar className="w-3.5 h-3.5" />
            <span data-testid={`text-duedate-${assignment.id}`}>{formatDate(assignment.dueDate)}</span>
          </div>
        )}
      </div>
    </Card>
  );
}

function AssignmentSkeleton() {
  return (
    <Card className="p-6">
      <div className="flex flex-col gap-3">
        <div className="flex items-start justify-between gap-4">
          <Skeleton className="h-5 w-48" />
          <Skeleton className="h-5 w-20 rounded-full" />
        </div>
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-24" />
      </div>
    </Card>
  );
}

function EmptyState({ onAddClick }: { onAddClick: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4" data-testid="empty-state">
      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-6">
        <FileText className="w-8 h-8 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold text-foreground mb-2">No assignments yet</h3>
      <p className="text-sm text-muted-foreground mb-6 text-center max-w-sm">
        Start tracking your assignments by creating your first one.
      </p>
      <Button onClick={onAddClick} data-testid="button-create-first">
        <Plus className="w-4 h-4 mr-2" />
        Create your first assignment
      </Button>
    </div>
  );
}

function AddAssignmentForm({ onSuccess }: { onSuccess: () => void }) {
  const { toast } = useToast();
  
  const form = useForm<InsertAssignment>({
    resolver: zodResolver(insertAssignmentSchema),
    defaultValues: {
      title: "",
      description: "",
      dueDate: "",
      status: "pending",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertAssignment) => {
      const response = await apiRequest("POST", "/api/assignments", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assignments"] });
      toast({
        title: "Assignment created",
        description: "Your new assignment has been added successfully.",
      });
      form.reset();
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create assignment",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertAssignment) => {
    createMutation.mutate(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Title *</FormLabel>
              <FormControl>
                <Input 
                  placeholder="Enter assignment title" 
                  {...field} 
                  data-testid="input-title"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Enter assignment description (optional)" 
                  className="resize-none h-24"
                  {...field} 
                  value={field.value || ""}
                  data-testid="input-description"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="dueDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Due Date</FormLabel>
              <FormControl>
                <Input 
                  type="date" 
                  {...field} 
                  value={field.value || ""}
                  data-testid="input-duedate"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="status"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Status</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-3 pt-4">
          <Button 
            type="submit" 
            disabled={createMutation.isPending}
            data-testid="button-submit"
          >
            {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Save Assignment
          </Button>
        </div>
      </form>
    </Form>
  );
}

export default function Home() {
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: assignments, isLoading, error } = useQuery<Assignment[]>({
    queryKey: ["/api/assignments"],
  });

  const handleFormSuccess = () => {
    setDialogOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-6xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between gap-4">
          <h1 className="text-xl font-semibold text-foreground" data-testid="text-app-title">
            Assignment Tracker
          </h1>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-assignment">
                <Plus className="w-4 h-4 mr-2" />
                Add Assignment
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Assignment</DialogTitle>
              </DialogHeader>
              <AddAssignmentForm onSuccess={handleFormSuccess} />
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 md:px-6 py-8">
        {isLoading ? (
          <div className="space-y-4">
            <AssignmentSkeleton />
            <AssignmentSkeleton />
            <AssignmentSkeleton />
          </div>
        ) : error ? (
          <div className="text-center py-16" data-testid="error-state">
            <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-6">
              <AlertCircle className="w-8 h-8 text-destructive" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Something went wrong</h3>
            <p className="text-sm text-muted-foreground">
              Failed to load assignments. Please try again later.
            </p>
          </div>
        ) : !assignments || assignments.length === 0 ? (
          <EmptyState onAddClick={() => setDialogOpen(true)} />
        ) : (
          <div className="space-y-4" data-testid="assignment-list">
            {assignments.map((assignment) => (
              <AssignmentCard key={assignment.id} assignment={assignment} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
